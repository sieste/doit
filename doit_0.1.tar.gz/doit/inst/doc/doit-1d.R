## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  fig.path = paste('figure/', knitr::current_input(), '-figs/', sep=''),
  fig.width = 7,
  fig.height = 5
)

## ---- echo=TRUE, eval=FALSE----------------------------------------------
#  library(doit)
#  library(lhs)
#  library(tidyverse)

## ---- echo=FALSE, eval=TRUE----------------------------------------------
suppressPackageStartupMessages(library(doit))
suppressPackageStartupMessages(library(lhs))
suppressPackageStartupMessages(library(tidyverse))

## ------------------------------------------------------------------------
h = function(r) {
  p = 1/(1+exp(-r))
  dbinom(1, 1, p) * dnorm(r, 1, 4)
}

## ------------------------------------------------------------------------
design = data.frame(x=seq(-10, 20, len=10))
design$f = sapply(design$x, h)

## ------------------------------------------------------------------------
w = doit_estimate_w(design)
print(w)

## ------------------------------------------------------------------------
doit = doit_fit(design, w=w)

## ------------------------------------------------------------------------
theta_eval = data.frame(x = seq(-15,25,.1))
doit_out = doit_approx(doit, theta_eval)

## ------------------------------------------------------------------------
head(doit_out)

## ----plot-doit-approx----------------------------------------------------
ggplot() + 
geom_line(data=doit_out, aes(x=x, y=dens_approx, colour=variance)) +
geom_point(data=design, aes(x=x, y=0), pch=1, cex=2)

## ------------------------------------------------------------------------
x_n = doit_propose_new(doit)
design_new = mutate(x_n, f=h(x))

## ------------------------------------------------------------------------
doit = doit_update(doit, design_new)

## ----plot-doit-approx-update---------------------------------------------
doit_out = doit_approx(doit, theta_eval)
ggplot() + 
geom_point(data=design_new, aes(x=x, y=0), pch=1, cex=2, col='red') +
geom_point(data=design, aes(x=x, y=0), pch=1, cex=2) +
geom_line(data=doit_out, aes(x=x, y=dens_approx, colour=variance))

## ------------------------------------------------------------------------
doit_expectation(doit)
doit_variance(doit)

