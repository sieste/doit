## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  fig.path = paste('figure/', knitr::current_input(), '-figs/', sep=''),
  fig.width = 7,
  fig.height = 5
)

## ---- eval=FALSE, echo=TRUE----------------------------------------------
#  library(doit)
#  library(tidyverse)
#  library(mvtnorm)
#  library(viridis)
#  library(lhs)

## ---- eval=TRUE, echo=FALSE----------------------------------------------
suppressPackageStartupMessages(library(doit))
suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(mvtnorm))
suppressPackageStartupMessages(library(viridis))
suppressPackageStartupMessages(library(lhs))

## ------------------------------------------------------------------------
f = function(theta) {
  theta = as.matrix(theta)
  theta = matrix(theta, ncol=2) 
  x = cbind(theta[ , 1, drop=FALSE], 
            theta[ , 2, drop=FALSE] + 0.03 * theta[ , 1, drop=FALSE] ^ 2 - 3)
  dmvnorm(x, c(0,0), diag(c(100, 1)))
}

df_true = crossing(theta1 = seq(-30, 30, .5), theta2 = seq(-12,7,.5)) %>%
  mutate(f = f(cbind(theta1,theta2)))

head(df_true)

## ----plot-true-----------------------------------------------------------
ggplot(df_true) + 
  geom_raster(aes(x=theta1, y=theta2, fill=f)) + 
  geom_contour(aes(x=theta1, y=theta2, z=f), col='black', lty=2) + 
  scale_fill_viridis()

## ------------------------------------------------------------------------
set.seed(123)
lhs = maximinLHS(n=100, k=2) %>% 
  as_data_frame %>% 
  setNames(c('theta1', 'theta2')) %>%
  mutate(theta1 = theta1 * 55 - 27.5, 
         theta2 = theta2 * 15 - 10)
design = lhs %>% mutate(f = f(cbind(theta1, theta2)))
head(design)

## ----plot-design---------------------------------------------------------
ggplot(design) + 
  geom_point(aes(x=theta1, y=theta2, colour=f), cex=3) + 
  scale_colour_gradient2()

## ------------------------------------------------------------------------
w = doit_estimate_w(design)
print(w)

## ------------------------------------------------------------------------
doit = doit_fit(design, w=w)
str(doit)

## ------------------------------------------------------------------------
theta_eval = df_true %>% select(theta1, theta2)
df_approx = doit_approx(doit, theta_eval)

## ----plot-approx---------------------------------------------------------
plot_df = bind_rows(df_approx %>% rename(f=dens_approx) %>% 
                                  mutate(type='approx'),
                    df_true %>% mutate(type='true'))
ggplot(plot_df, aes(x=theta1, y=theta2)) + 
  geom_raster(aes(fill=f)) + 
  facet_wrap(~type) +
  geom_point(data=design, pch=1, colour='white') + 
  scale_colour_viridis() + scale_fill_viridis()

## ----plot-variance-------------------------------------------------------
ggplot(df_approx, aes(x=theta1, y=theta2)) + 
  geom_raster(aes(fill=variance)) + 
  geom_point(data=design, pch=1, colour='white') + 
  scale_colour_viridis() + scale_fill_viridis()

## ------------------------------------------------------------------------
theta_n = doit_propose_new(doit)
print(theta_n)

## ----plot-design-update-1------------------------------------------------
ggplot(df_approx, aes(x=theta1, y=theta2)) + 
  geom_raster(aes(fill=variance)) + 
  scale_fill_viridis() +
  geom_point(data=design, pch=1, col='white') +
  geom_point(data=theta_n, pch=16, cex=3, col='red')

## ------------------------------------------------------------------------
n_new = 75
for (jj in 1:n_new) {
  theta_n    = doit_propose_new(doit)
  design_add = theta_n %>% mutate(f = f(theta_n))
  design = bind_rows(design, design_add)
  if (jj %% 10 != 0) {
    doit = doit_update(doit, design_add)
  } else { 
    w = doit_estimate_w(design, w_0=doit$w)
    doit = doit_fit(design, w=w)
  }
}

## ----plot-design-update-75-----------------------------------------------
theta_eval = df_true %>% select(theta1, theta2)
df_approx = doit_approx(doit, theta_eval)
ggplot(mapping=aes(x=theta1, y=theta2)) +
  geom_raster(data=df_approx, aes(fill=dens_approx)) + 
  geom_point(data=design %>% 
                  mutate(type=rep(c('initial','sequential'), c(n()-n_new, n_new))),
             mapping=aes(pch=type, colour=type), cex=2) + 
  scale_fill_viridis()

## ------------------------------------------------------------------------
df_marg = doit_marginals(doit, theta_eval)
ggplot(df_marg, aes(x=theta, y=dens_approx)) + 
  geom_point() + geom_line() + 
  facet_wrap(~par, scales='free')

## ------------------------------------------------------------------------
df_marg_theta1 = doit_marginal(doit, 'theta1')
head(df_marg_theta1)

## ------------------------------------------------------------------------
doit_expectation(doit)

## ------------------------------------------------------------------------
doit_variance(doit)

